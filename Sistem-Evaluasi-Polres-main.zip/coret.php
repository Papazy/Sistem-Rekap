<?php

    require_once("config/conn.php");
    require_once("utils.php");
    print_r(hitungPersentaseDariPeriode( "Polres", "2024-03-11", "Hijau"));
?>